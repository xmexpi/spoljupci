<div class="box3">
    <div class="row">
        <div class="span2">
            <div class="bot1_block">
                <div class="bot1_title">MAIN MENU</div>
                <ul class="ul0">
                    <li><a href="index.html">Main page</a></li>
                    <li><a href="index-1.html">About us</a></li>
                    <li><a href="index-2.html">Shows</a></li>
                    <li><a href="index-3.html">Podcasts</a></li>
                    <li><a href="index-4.html">Gallery</a></li>
                    <li><a href="index-5.html">Contacts</a></li>
                </ul>
            </div>
        </div>
        <div class="span4">
            <div class="bot1_block">
                <div class="bot1_title">PROGRAMS</div>
            </div>
            <div class="row">
                <div class="span2">
                    <div class="bot1_block">
                        <ul class="ul0">
                            <li><a href="#">Lorem ipsum dolor</a></li>
                            <li><a href="#">Sit amet consectetue</a></li>
                            <li><a href="#">Adipiscing elit</a></li>
                            <li><a href="#">Nunc suscipit</a></li>
                            <li><a href="#">Suspendisse enim</a></li>
                            <li><a href="#">Convallis non cursus</a></li>
                            <li><a href="#">Dignissim et est</a></li>
                        </ul>
                    </div>
                </div>
                <div class="span2">
                    <div class="bot1_block">
                        <ul class="ul0">
                            <li><a href="#">Lorem ipsum dolor</a></li>
                            <li><a href="#">Sit amet consectetue</a></li>
                            <li><a href="#">Adipiscing elit</a></li>
                            <li><a href="#">Nunc suscipit</a></li>
                            <li><a href="#">Suspendisse enim</a></li>
                            <li><a href="#">Convallis non cursus</a></li>
                            <li><a href="#">Dignissim et est</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="span4">
            <div class="kv2">
                <div class="txt1">Call us:</div>
                <div class="txt2">1 800 123 4567</div>
                <div class="txt3">Address:</div>
                <div class="txt4">8901 Marmora Road, Glasgow, D04 89GR.<br>
                    Telephone: +1 800 123 1234<br>
                    E-mail: <a href="#">mail@bteamny.com</a></div>
                <a href="#" class="button1">Location</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" class="button1">Contact Us</a>
            </div>
        </div>
    </div>
</div>
<div class="box4">
    <footer>
        <div class="copyright">Copyright © 2013. All rights reserved.</div>
    </footer>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript" src="{snippet:template_path}js/bootstrap.js"></script>

</body>

</html>