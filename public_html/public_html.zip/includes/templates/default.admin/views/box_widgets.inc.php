<div id="box-widgets">

  <?php foreach ($widgets as $widget) echo $widget['content']; ?>

</div>