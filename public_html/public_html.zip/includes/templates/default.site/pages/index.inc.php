<div id="sidebar">
  SIDEBAR
</div>

<div id="content">
  {snippet:notices}

   MAIN PAGE

</div>
