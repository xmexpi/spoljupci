<nav id="site-menu" class="navbar hidden-print">
MENU BOX
</nav>
