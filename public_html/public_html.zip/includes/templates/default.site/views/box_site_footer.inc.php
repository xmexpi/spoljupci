<footer id="footer" class="hidden-print">
FOOTER
</footer>
