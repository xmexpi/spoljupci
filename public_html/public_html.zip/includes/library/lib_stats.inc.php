<?php

  class stats {

    private static $_data;
    private static $_page_parse_start;
    private static $_capture_parse_start;

    public static function init() {

      self::$_data = array(
        'page_parse_time' => 0, // s
        'page_capture_time' => 0, // s
        'memory_peak_usage' => 0, // percent
        'database_queries' => 0, // qty
        'database_execution_time' => 0, // s
        'http_requests' => 0, // qty
        'http_duration' => 0, // s
        'output_optimization' => 0, // s
      );

    // Set time stamp for execution
      self::$_page_parse_start = microtime(true);

      event::register('before_capture', array(__CLASS__, 'before_capture'));
      event::register('after_capture', array(__CLASS__, 'after_capture'));
      event::register('before_output', array(__CLASS__, 'before_output'));
    }

    ######################################################################

    public static function before_capture() {
      self::$_capture_parse_start = microtime(true);
    }

    public static function after_capture() {

    // Capture parse time
      $page_parse_time = microtime(true) - self::$_page_parse_start;
      self::set('page_capture_time', $page_parse_time);

      if (self::get('page_parse_time') > 5) {
        notices::add('warnings', sprintf(language::translate('text_long_execution_time', 'We apologize for the inconvenience that the server seems temporarily overloaded right now.'), number_format($page_parse_time, 1, ',', ' ')));
        error_log('Warning: Long page execution time '. number_format($page_parse_time, 3, ',', ' ') .' s - '. $_SERVER['REQUEST_URI']);
      }
    }

    public static function before_output() {

    // Memory peak usage
      self::set('memory_peak_usage', memory_get_peak_usage(true) / 1e6);

    // Page parse time
      $page_parse_time = microtime(true) - self::$_page_parse_start;
      self::set('page_parse_time', $page_parse_time);

    // Output stats
      $stats = '<!--' . PHP_EOL
             . '  System Statistics:' . PHP_EOL
             . '  - Page Parse Time: ' . number_format(self::get('page_parse_time')*1000, 0, '.', ' ') . ' ms' . PHP_EOL
             . '  - Page Capture Time: ' . number_format(self::get('page_capture_time')*1000, 0, '.', ' ') . ' ms' . PHP_EOL
             . '  - Included Files: ' . count(get_included_files()) . PHP_EOL
             . '  - Memory Peak: ' . number_format(self::get('memory_peak_usage'), 2, '.', ' ') . ' MB / '. ini_get('memory_limit') . PHP_EOL
             . '  - Database Queries: ' . number_format(self::get('database_queries'), 0, '.', ' ') . PHP_EOL
             . '  - Database Parse Time: ' . number_format(self::get('database_execution_time')*1000, 0, '.', ' ') . ' ms (' . number_format(self::get('database_execution_time')/self::get('page_parse_time')*100, 0, '.', ' ') . ' %)' . PHP_EOL
             . '  - Network Requests: ' . self::get('http_requests') . PHP_EOL
             . '  - Network Requests Duration: ' . number_format(self::get('http_duration')*1000, 0, '.', ' ') . ' ms (' . number_format(self::get('http_duration')/self::get('page_parse_time')*100, 0, '.', ' ') . ' %)' . PHP_EOL
             . '  - Output Optimization: ' . number_format(self::get('output_optimization')*1000, 0, '.', ' ') . ' ms (' . number_format(self::get('output_optimization')/self::get('page_parse_time')*100, 0, '.', ' ') . ' %)' . PHP_EOL
             . '  - vQmod: ' . number_format(vmod::get_time_elapsed()*1000, 0, '.', ' ') . ' ms (' . number_format(vmod::get_time_elapsed()/self::get('page_parse_time')*100, 0, '.', ' ') . ' %)' . PHP_EOL
             . '-->';

      $GLOBALS['output'] = preg_replace('#</html>$#', '</html>' . PHP_EOL . $stats, $GLOBALS['output']);
    }

    public static function set($key, $value) {
      self::$_data[$key] = $value;
    }

    public static function get($key) {
      if (isset(self::$_data[$key])) return self::$_data[$key];
    }
  }
