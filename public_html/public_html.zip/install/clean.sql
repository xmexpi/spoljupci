DROP TABLE IF EXISTS `xp_countries`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_currencies`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_customers`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_emails`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_geo_zones`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_languages`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_modules`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_pages`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_pages_info`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_settings`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_slides`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_slides_info`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_team`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_settings_groups`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_translations`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_users`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_zones`;
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_zones_to_geo_zones`;
