INSERT INTO `xp_zones` (`country_code`, `code`, `name`) VALUES
('CA', 'AB', 'Alberta'),
('CA', 'BC', 'British Columbia'),
('CA', 'MB', 'Manitoba'),
('CA', 'NB', 'New Brunswick'),
('CA', 'NL', 'Newfoundland and Labrador'),
('CA', 'NT', 'Northwest Territories'),
('CA', 'NS', 'Nova Scotia'),
('CA', 'NU', 'Nunavut'),
('CA', 'ON', 'Ontario'),
('CA', 'PE', 'Prince Edward Island'),
('CA', 'QC', 'Québec'),
('CA', 'SK', 'Saskatchewan'),
('CA', 'YT', 'Yukon Territory');
